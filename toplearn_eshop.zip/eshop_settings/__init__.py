default_app_config = 'eshop_settings.apps.EshopSettingsConfig'
