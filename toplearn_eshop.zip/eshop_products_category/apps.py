from django.apps import AppConfig


class EshopProductsCategoryConfig(AppConfig):
    name = 'eshop_products_category'
    verbose_name = "دسته بندی ها"
