default_app_config = 'eshop_products_category.apps.EshopProductsCategoryConfig'
