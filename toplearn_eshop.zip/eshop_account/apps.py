from django.apps import AppConfig


class EshopAccountConfig(AppConfig):
    name = 'eshop_account'
