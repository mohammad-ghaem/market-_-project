from django.apps import AppConfig


class EshopTagConfig(AppConfig):
    name = 'eshop_tag'
    verbose_name = 'ماژول برچسب ها'
