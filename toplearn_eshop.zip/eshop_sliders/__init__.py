default_app_config = "eshop_sliders.apps.EshopSlidersConfig"
