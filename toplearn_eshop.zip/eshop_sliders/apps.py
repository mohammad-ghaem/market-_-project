from django.apps import AppConfig


class EshopSlidersConfig(AppConfig):
    name = 'eshop_sliders'
    verbose_name = 'ماژول اسلایدرها'
